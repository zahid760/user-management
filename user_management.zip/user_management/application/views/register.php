<?php require_once('header.php'); ?>
    <section>
        <div class="container">
            <div class="row justify-content-center align-items-center vh-100">
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header">Register Form</div>
                        <div class="card-body">
                            <form method="post" id="form_register" onsubmit="return false;">
                                <div class="mb-3">
                                    <label class="form-label">Username</label>
                                    <input type="text" name="username" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Email address</label>
                                    <input type="email" name="email" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control">
                                </div>
                                <button type="submit" class="btn btn-primary" id="savebtn">Register</button>
                                <p class="mt-3">Do you have an account? <a href="<?=base_url();?>">Login</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php require_once('footer.php'); ?>

<script>
    $('#form_register').on('submit', function(e)
    {
        var data = $('#form_register').serialize();
        $.ajax({
            url: '<?=base_url();?>registration',
            type: 'POST',
            data: data,
            dataType: 'json',
            beforeSend: function()
            {
                $('#savebtn').prop('disabled', true);
            },
            complete: function()
            {
                $('#savebtn').prop('disabled', false);
            },
            success: function(response)
            {
                if(response.error)
                    toastr.error('<h4>'+response.title+'</h4> <p>'+response.message+'</p>');
                else
                {
                    toastr.success('<h4>'+response.title+'</h4> <p>'+response.message+'</p>');
                    $('#form_register')[0].reset();
                }
            }
        });
    });
</script>
