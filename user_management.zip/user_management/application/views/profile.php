<?php require_once('header.php'); ?>
    <section>
        <div class="container">
            <div class="row justify-content-center align-items-center vh-100">
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header">User Profile</div>
                        <div class="card-body">
                            <table class="table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">Username</th>
                                        <th scope="col">Email</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?= $data['username'];?></td>
                                        <td><?= $data['email'];?></td>
                                    </tr>
                                </tbody>
                            </table>    
                            
                            <div class="text-center">
                                <a href="<?=base_url('logout');?>" class="btn btn-primary" id="logoutbtn">Logout</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php require_once('footer.php'); ?>
