<?php require_once('header.php'); ?>
    <section>
        <div class="container">
            <div class="row justify-content-center align-items-center vh-100">
                <div class="col-lg-4">
                    <?php 
                        if($this->session->has_userdata('message')){
                            echo '<div class="alert alert-danger" role="alert">'.$this->session->flashdata('message')['message'].'</div>';
                        }
                    ?>
                    <div class="card">
                        <div class="card-header">Login Form</div>
                        <div class="card-body">
                            <form method="post" id="form_login" onsubmit="return false;">
                                <div class="mb-3">
                                    <label class="form-label">Username</label>
                                    <input type="text" name="username" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Password</label>
                                    <input type="password" name="password" class="form-control">
                                </div>
                                <button type="submit" class="btn btn-primary" id="savebtn">Login</button>
                                <p class="mt-3">Don't have an account? <a href="<?=base_url('register');?>">Create Account</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php require_once('footer.php'); ?>

<script>
    $('#form_login').on('submit', function(e)
    {
        var data = $('#form_login').serialize();
        $.ajax({
            url: '<?=base_url();?>login',
            type: 'POST',
            data: data,
            dataType: 'json',
            beforeSend: function()
            {
                $('#savebtn').prop('disabled', true);
            },
            complete: function()
            {
                $('#savebtn').prop('disabled', false);
            },
            success: function(response)
            {
                if(response.error)
                    toastr.error('<h4>'+response.title+'</h4> <p>'+response.message+'</p>');
                else
                {
                    toastr.success('<h4>'+response.title+'</h4> <p>'+response.message+'</p>');
                    $('#form_login')[0].reset();
                    setTimeout(function(){
                        window.location.href = 'profile';
                    }, 2000);
                }
            }
        });
    });
</script>
