<?php
class Login_model extends CI_Model{

    public function login($uname){
        return $this->db->select('*')->get_where('users', array('username'=>$uname))->row();
    }
}
?>