<?php
class Insertions_model extends CI_Model{

    public function insert($data){
        return $this->db->insert('users',$data);
    }

    public function update($uname,$token){
        $this->db->set('token', $token);
        $this->db->where('username', $uname);
        return $this->db->update('users');
    }
}
?>