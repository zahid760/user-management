<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function login()
	{
		$this->load->view('login');
	}

    public function register()
	{
		$this->load->view('register');
	}

	// User registration
	public function user_registration()
	{		
		$data = json_encode($this->input->post());

		$url = base_url().'api/register';
		$headers = array(
			'Content-Type: application/json',
			'Accept: application/json'
		);

		$ch = curl_init();
		curl_setopt( $ch,CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");  
		curl_setopt($ch, CURLOPT_POST,1 );                                                
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data); 
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true ); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$result = curl_exec($ch);
		$result = json_decode($result,1);
		curl_close( $ch );
		
		if($result['status'] == true)
		{
			$output['title'] = 'Congrats';
			$output['message'] = $result['response'];
		}
		else{
			$output['error'] = true;
			$output['title'] = 'Error';
			$output['message'] = $result['response'];
		}
		echo json_encode($output);
	}

	// User login
	public function user_login()
	{		
		$data = json_encode($this->input->post());

		$url = base_url().'api/login';
		$headers = array(
			'Content-Type: application/json',
			'Accept: application/json'
		);

		$ch = curl_init();
		curl_setopt( $ch,CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");  
		curl_setopt($ch, CURLOPT_POST,1 );                                                
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data); 
		curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true ); 
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$result = curl_exec($ch);
		$result = json_decode($result,1);
		curl_close( $ch );
		
		if($result['status'] == true)
		{
			$output['title'] = 'Welcome';
			$output['message'] = 'Login Successfull';
			$this->session->set_userdata('token', $result['response']);
		}
		else{
			$output['error'] = true;
			$output['title'] = 'Error';
			$output['message'] = $result['response'];
		}
		echo json_encode($output);
	}

	// User profile
	public function user_profile()
	{
		if($this->session->has_userdata('token'))
		{
			$token = $this->session->userdata('token');
			
			$headers = array(
				'Token: '.$token,
				'Content-Type: application/json',
				'Accept: application/json'
			);

			$url = base_url().'api/profile';

			$ch = curl_init();
			curl_setopt( $ch,CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");  
			curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
			curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true ); 
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			$result = curl_exec($ch);
			$result = json_decode($result,1);
			curl_close( $ch );

			if($result['status'] == true)
			{
				$data['data'] = $result['response'];
				$this->load->view('profile', $data);
			}
			else{
				$output['error'] = true;
				$output['title'] = 'Error';
				$output['message'] = $result['response'];
				$this->session->set_flashdata('message', $output);
				redirect('/');
			}
		}
		else
			redirect('/');
	}

	// User logout
	public function user_logout()
	{
		if($this->session->has_userdata('token'))
		{
			$token = $this->session->userdata('token');

			$url = base_url().'api/logout';
			$headers = array(
				'Token: '.$token,
				'Content-Type: application/json',
				'Accept: application/json'
			);

			$ch = curl_init();
			curl_setopt( $ch,CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");  
			curl_setopt($ch, CURLOPT_POST,1 );                                                
			curl_setopt($ch, CURLOPT_POSTFIELDS, true); 
			curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
			curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true ); 
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			$result = curl_exec($ch);
			$result = json_decode($result,1);
			curl_close( $ch );

			$this->session->unset_userdata('token');
			$this->session->sess_destroy();
			redirect('/');
		}
		else
			redirect('/');
	}
}
