<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once('vendor/autoload.php');
require(APPPATH.'/libraries/RestController.php');
use chriskacerguis\RestServer\RestController;

class Api extends RestController {

    function __construct() {
        parent::__construct();
        $this->load->model('insertions_model');
        $this->load->model('Login_model');
        $this->load->library('Authorization_Token');
    } 

	public function register_post()
    {
        $statusCode = RestController::HTTP_OK;
		$output['status'] = false;
		$output['error'] = true;
        $_POST = (array) json_decode(file_get_contents('php://input'), TRUE);
        if ($_SERVER['REQUEST_METHOD'] === 'POST')
        {
            if (!empty($_POST))
            {
                $this->form_validation->set_rules('username', 'Username', 'required|trim|alpha_numeric|min_length[4]|is_unique[users.username]');
                $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
                $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[6]');

                $this->form_validation->set_message('required', '%s is required');
                $this->form_validation->set_message('is_unique', 'This %s is already registered.');

                if($this->form_validation->run() == TRUE)
                {
                    $data = array(
                        'username' => $_POST['username'],
                        'email' => $this->input->post('email'),
                        'password' => password_hash($this->input->post('password'),PASSWORD_BCRYPT),
                    );
                    
                    $result = $this->insertions_model->insert($data);
                    if($result == true)
                    {
                        $output['status'] = true;
                        $output['error'] = false;
                        $output['response'] = 'Registraion successfully.';
                    }
                    else {
                        $output['response'] = 'Some Error occurred, Try again.';
                    }
                }
                else{
                    $statusCode         = RestController::HTTP_BAD_REQUEST;
                    $output['response'] = validation_errors(); 
                }
            }
            else {
                $statusCode         = RestController::HTTP_BAD_REQUEST;
                $output['response'] = 'Invalid data format'; 
            }
        }
        else {
			$statusCode         = RestController::HTTP_FORBIDDEN;
			$output['response'] = 'Invalid request method';
		}
        $this->response($output, $statusCode);
    }

    public function login_post()
    {
        $statusCode = RestController::HTTP_OK;
		$output['status'] = false;
		$output['error'] = true;
        $_POST = (array) json_decode(file_get_contents('php://input'), TRUE);
        if ($_SERVER['REQUEST_METHOD'] === 'POST')
        {
            if (!empty($_POST))
            {
                $this->form_validation->set_rules('username', 'Username', 'required|trim|alpha_numeric|min_length[4]');
                $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[6]');

                $this->form_validation->set_message('required', '%s is required');

                if($this->form_validation->run() == TRUE)
                {
                    $logged_user = $this->Login_model->login($this->input->post('username'));
                    if($logged_user && password_verify($this->input->post('password'),$logged_user->password))
                    {
                        $data = array(
                            'username' => $this->input->post('username'),
                            'password' => $logged_user->password,
                        );
                        $token = $this->authorization_token->generateToken($data);
                       
                        $output['status'] = true;
                        $output['error'] = false;
                        $output['response'] = $token;
                    }
                    else
                        $output['response'] = 'Invalid username or password.';
                }
                else{
                    $statusCode         = RestController::HTTP_BAD_REQUEST;
                    $output['response'] = validation_errors(); 
                }
            }
            else {
                $statusCode         = RestController::HTTP_BAD_REQUEST;
                $output['response'] = 'Invalid data format'; 
            }
        }
        else {
			$statusCode         = RestController::HTTP_FORBIDDEN;
			$output['response'] = 'Invalid request method';
		}
        $this->response($output, $statusCode);
    }

    public function profile_get()
    {
        $statusCode = RestController::HTTP_OK;
		$output['status'] = false;
		$output['error'] = true;
        if ($_SERVER['REQUEST_METHOD'] === 'GET')
        {
            $headers = $this->input->request_headers(); 
            if (isset($headers['Token']) && !empty($headers['Token'])) 
            {
                $decoded_token = $this->authorization_token->validateToken($headers['Token']);
                
                if($decoded_token['status'] == TRUE)
                {
                    $logged_user = $this->Login_model->login($decoded_token['data']->username);
                    if($headers['Token'] != $logged_user->token){
                        $data = array(
                            'username' => $logged_user->username,
                            'email' => $logged_user->email
                        );
                        $output['status'] = true;
                        $output['error'] = false;
                        $output['response'] = $data;
                    }
                    else{
                        $output['response'] = 'Invalid token'; 
                    }
                }
                else
                    $output['response'] = $decoded_token['message'];
            }
            else {
                $statusCode         = RestController::HTTP_UNAUTHORIZED;
                $output['response'] = 'Authentication error';
            }
        }
        else {
			$statusCode         = RestController::HTTP_FORBIDDEN;
			$output['response'] = 'Invalid request method';
		}
        $this->response($output, $statusCode);
    }

    public function logout_post()
    {
        $statusCode = RestController::HTTP_OK;
		$output['status'] = false;
		$output['error'] = true;
        if ($_SERVER['REQUEST_METHOD'] === 'POST')
        {
            $headers = $this->input->request_headers(); 
            if (isset($headers['Token']) && !empty($headers['Token'])) {
                $decoded_token = $this->authorization_token->validateToken($headers['Token']);
                if($decoded_token['status'] == TRUE)
                {
                    $result = $this->insertions_model->update($decoded_token['data']->username, $headers['Token']);
                    if($result == true)
                    {
                        $output['status'] = true;
                        $output['error'] = false;
                        $output['response'] = 'Logout successfully.';
                    }
                    else {
                        $output['response'] = 'Some Error occurred, Try again.';
                    }
                }
                else{
                    $output['status'] = true;
                    $output['error'] = false;
                    $output['response'] = 'Logout successfully.';
                }
            }
            else {
                $statusCode         = RestController::HTTP_UNAUTHORIZED;
                $output['response'] = 'Authentication error';
            }
        }
        else {
			$statusCode         = RestController::HTTP_FORBIDDEN;
			$output['response'] = 'Invalid request method';
		}
        $this->response($output, $statusCode);
    }

    
}
