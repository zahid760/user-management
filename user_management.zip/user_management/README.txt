# Download Zip file and extract in root folder
# change base_url in config.php and file path (user_management\application\config)
# database configuration in database.php path (user_management\application\config)

API end point
----------------------
 /api/register
 /api/login
 /api/profile
 /api/logout


